package com.chernobyl.explorer.controlador;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.chernobyl.explorer.entidades.Usuario;
import com.chernobyl.explorer.repositorio.UsuarioRepository;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/usuarios")
@Tag(name = "Gestión de Usuarios (Login)", description = "Controladores para el registro y credenciales de acceso")
public class UsuarioController {

	@Autowired
	private UsuarioRepository usuarioRepository;

	@Autowired
	private PasswordEncoder codificadorContrasenas;

	@Operation(summary = "Registrar nuevo cliente", description = "Crea unas credenciales de acceso con rol CLIENTE por defecto.")
	@PostMapping("/registro-cliente")
	public ResponseEntity<String> registrarCliente(@Valid @RequestBody Usuario nuevoUsuario) {
		if (comprobarSiExiste(nuevoUsuario.getCuenta())) {
			return ResponseEntity.badRequest().body("Error: El usuario ya existe.");
		}

		nuevoUsuario.setClave(codificadorContrasenas.encode(nuevoUsuario.getClave()));
		nuevoUsuario.setRol("ROLE_CLIENTE");
		
		usuarioRepository.save(nuevoUsuario);
		return ResponseEntity.status(HttpStatus.CREATED).body("Cliente registrado con éxito.");
	}

	@Operation(summary = "Registrar personal interno", description = "Exclusivo para administradores. Permite registrar empleados o supervisores.")
	@PostMapping("/registro-empleado")
	public ResponseEntity<String> registrarEmpleado(@Valid @RequestBody Usuario nuevoUsuario) {
		if (comprobarSiExiste(nuevoUsuario.getCuenta())) {
			return ResponseEntity.badRequest().body("Error: El usuario ya existe.");
		}

		nuevoUsuario.setClave(codificadorContrasenas.encode(nuevoUsuario.getClave()));
		
		if (!nuevoUsuario.getRol().startsWith("ROLE_")) {
			nuevoUsuario.setRol("ROLE_" + nuevoUsuario.getRol().toUpperCase());
		}
		
		usuarioRepository.save(nuevoUsuario);
		return ResponseEntity.status(HttpStatus.CREATED).body("Personal interno registrado como " + nuevoUsuario.getRol());
	}

	private boolean comprobarSiExiste(String cuenta) {
		return usuarioRepository.findAll().stream().anyMatch(u -> u.getCuenta().equals(cuenta));
	}
}