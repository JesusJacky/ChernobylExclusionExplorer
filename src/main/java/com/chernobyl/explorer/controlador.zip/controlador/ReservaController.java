package com.chernobyl.explorer.controlador;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.chernobyl.explorer.dto.PagoDTO;
import com.chernobyl.explorer.entidades.Reserva;
import com.chernobyl.explorer.servicio.ReservaService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/reservas")
@Tag(name = "Gestión de Reservas y Dosimetría", description = "Motor principal: pagos, aprobaciones, cancelaciones y cálculo de radiación")
public class ReservaController {

	@Autowired
	private ReservaService reservaService;

	@Operation(summary = "Listar todas las reservas")
	@GetMapping
	public List<Reserva> listarReservas() {
		return reservaService.listarTodos();
	}

	@Operation(summary = "Obtener reserva por ID")
	@GetMapping("/{id}")
	public ResponseEntity<Reserva> obtenerPorId(@PathVariable Integer id) {
		Reserva resultado = reservaService.buscarPorId(id);
		return ResponseEntity.ok(resultado);
	}

	@Operation(summary = "Filtrar reservas por estado", description = "Útil para la intranet. Permite buscar reservas PENDIENTES, ACEPTADAS, etc.")
	@GetMapping("/estado/{estado}")
	public ResponseEntity<List<Reserva>> listarPorEstado(@PathVariable String estado) {
		List<Reserva> resultado = reservaService.listarReservasPorEstado(estado);
		return ResponseEntity.ok(resultado);
	}

	@Operation(summary = "Búsqueda rápida por Localizador")
	@GetMapping("/buscar-localizador/{localizador}")
	public ResponseEntity<Reserva> buscarPorLocalizador(@PathVariable String localizador) {
		Reserva reserva = reservaService.buscarReservaPorLocalizador(localizador);
		return ResponseEntity.ok(reserva);
	}

	@Operation(summary = "Buscar las reservas de un Cliente (DNI)")
	@GetMapping("/buscar-dni/{dni}")
	public ResponseEntity<List<Reserva>> buscarPorDni(@PathVariable String dni) {
		List<Reserva> reservas = reservaService.buscarReservasPorDni(dni);
		return ResponseEntity.ok(reservas);
	}

	@Operation(summary = "Proceso completo de Reserva (WEB)", description = "Víncula a un cliente con un paquete y envía correo de confirmación.")
	@PostMapping("/proceso-reserva")
	public ResponseEntity<Reserva> crearReservaDetallada(@Valid @RequestBody(required = false) Reserva reserva,
			@RequestParam Integer idCliente, @RequestParam Integer idPaquete) {
		Reserva base = (reserva == null) ? new Reserva() : reserva;
		Reserva nueva = reservaService.crearReservaDetallada(base, idCliente, idPaquete);
		return ResponseEntity.status(HttpStatus.CREATED).body(nueva);
	}

	@Operation(summary = "Modificar reserva (Añadir Viajeros)", description = "Modifica datos de la reserva y permite añadir a otros viajeros si quedan plazas.")
	@PutMapping("/actualizar/{id}")
	public ResponseEntity<Reserva> actualizar(@PathVariable Integer id, @Valid @RequestBody Reserva reservaActualizada,
			@RequestParam(required = false) List<Integer> nuevosViajeros) {
		Reserva actualizada = reservaService.actualizarReserva(id, reservaActualizada, nuevosViajeros);
		return ResponseEntity.ok(actualizada);
	}

	@Operation(summary = "Cancelar expedición (Cliente)", description = "Anula la reserva si quedan más de 7 días para la expedición.")
	@PutMapping("/{id}/cancelar")
	public ResponseEntity<Reserva> cancelar(@PathVariable Integer id) {
		Reserva cancelada = reservaService.cancelarReserva(id);
		return ResponseEntity.ok(cancelada);
	}

	@Operation(summary = "Eliminación física (Cuidado)")
	@DeleteMapping("/{id}")
	public ResponseEntity<Void> eliminar(@PathVariable Integer id) {
		reservaService.eliminar(id);
		return ResponseEntity.noContent().build();
	}

	@Operation(summary = "Cálculo Dosimétrico Anual (Diario de Radiación)", description = "Suma los mSv de las expediciones realizadas por el cliente en el año actual.")
	@GetMapping("/dosimetria/{dni}")
	public ResponseEntity<Double> obtenerDosimetriaAnual(@PathVariable String dni) {
		Double radiacionAcumulada = reservaService.calcularRadiacionAnualCliente(dni);
		return ResponseEntity.ok(radiacionAcumulada);
	}

	// ==================== ZONA INTRANET ====================

	@Operation(summary = "Aprobar Reserva (Personal)", description = "Uso interno. Autoriza la expedición y notifica al cliente por email.")
	@PutMapping("/{id}/aprobar")
	public ResponseEntity<Reserva> aprobarPorPersonal(@PathVariable Integer id) {
		Reserva aprobada = reservaService.aprobarReservaPorPersonal(id);
		return ResponseEntity.ok(aprobada);
	}

	@Operation(summary = "Rechazar Reserva (Personal)", description = "Uso interno. Cancela la solicitud por motivos de seguridad y notifica al cliente.")
	@PutMapping("/{id}/rechazar")
	public ResponseEntity<Reserva> rechazarPorPersonal(@PathVariable Integer id, @RequestParam String motivo) {
		Reserva rechazada = reservaService.rechazarReservaPorPersonal(id, motivo);
		return ResponseEntity.ok(rechazada);
	}

	// ==================== ZONA PAGOS ====================

	@Operation(summary = "Procesar pago de Expedición", description = "Simula pasarela bancaria y envía comprobante al correo.")
	@PostMapping("/{id}/pagar")
	public ResponseEntity<String> procesarPago(@PathVariable Integer id, @Valid @RequestBody PagoDTO pago) {
		String transaccion = reservaService.procesarPago(id, pago);
		return ResponseEntity.ok("Pago procesado con éxito. Código de Transacción: " + transaccion);
	}
}