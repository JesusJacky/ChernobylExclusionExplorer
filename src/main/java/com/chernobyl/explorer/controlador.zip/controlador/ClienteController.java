package com.chernobyl.explorer.controlador;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.chernobyl.explorer.entidades.Cliente;
import com.chernobyl.explorer.servicio.ClienteService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/clientes")
@Tag(name = "Fichas de Clientes", description = "Operaciones CRUD y filtros para los expedicionarios")
public class ClienteController {

	@Autowired
	private ClienteService clienteService;

	@Operation(summary = "Listar todos los clientes", description = "Devuelve el registro completo de personas dadas de alta en el sistema.")
	@GetMapping
	public List<Cliente> listarClientes() {
		return clienteService.listarTodos();
	}

	@Operation(summary = "Obtener cliente por ID", description = "Busca un explorador por su identificador único de base de datos.")
	@GetMapping("/{id}")
	public ResponseEntity<Cliente> obtenerPorId(@PathVariable Integer id) {
		Cliente cliente = clienteService.buscarPorId(id);
		return ResponseEntity.ok(cliente);
	}

	@Operation(summary = "Filtrar por nacionalidad (Solo Adultos)", description = "Uso interno. Busca clientes de un país específico que sean mayores de edad.")
	@GetMapping("/buscar-nacionalidad-mayores")
	public ResponseEntity<List<Cliente>> buscarPorNacionalidadYMayorEdad(@RequestParam String nacionalidad) {
		List<Cliente> clientes = clienteService.buscarPorNacionalidadYMayorDeEdad(nacionalidad);
		return ResponseEntity.ok(clientes);
	}

	@Operation(summary = "Alerta de menores", description = "Uso interno. Filtra clientes que no han alcanzado la mayoría de edad.")
	@GetMapping("/buscar-menores")
	public ResponseEntity<List<Cliente>> filtrarPorMenorDeEdad() {
		List<Cliente> clientes = clienteService.filtrarPorMenorDeEdad();
		return ResponseEntity.ok(clientes);
	}

	@Operation(summary = "Búsqueda por DNI", description = "Encuentra el perfil exacto de un cliente mediante su documento de identidad.")
	@GetMapping("/buscar-dni/{dni}")
	public ResponseEntity<Cliente> buscarPorDni(@PathVariable String dni) {
		Cliente cliente = clienteService.buscarPorDni(dni);
		return ResponseEntity.ok(cliente);
	}

	@Operation(summary = "Dar de alta cliente", description = "Registra un nuevo cliente aplicando validaciones de edad y formato.")
	@PostMapping
	public ResponseEntity<Cliente> crear(@Valid @RequestBody Cliente cliente) {
		Cliente nuevoCliente = clienteService.crear(cliente);
		return ResponseEntity.status(HttpStatus.CREATED).body(nuevoCliente);
	}

	@Operation(summary = "Modificar ficha de cliente", description = "Actualiza los datos personales de un explorador (El DNI no puede ser modificado por seguridad).")
	@PutMapping("/actualizar/{id}")
	public ResponseEntity<Cliente> actualizar(@PathVariable Integer id, @Valid @RequestBody Cliente detallesCliente) {
		Cliente clienteActualizado = clienteService.actualizar(id, detallesCliente);
		return ResponseEntity.ok(clienteActualizado);
	}

	@Operation(summary = "Eliminar cliente", description = "Borra físicamente a un cliente de la base de datos.")
	@DeleteMapping("/{id}")
	public ResponseEntity<Void> eliminar(@PathVariable Integer id) {
		clienteService.eliminar(id);
		return ResponseEntity.noContent().build();
	}
}