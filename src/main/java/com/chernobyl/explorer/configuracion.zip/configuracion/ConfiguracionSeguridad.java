package com.chernobyl.explorer.configuracion;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

/**
 * Clase principal de configuración de seguridad de la aplicación. Utiliza
 * Spring Security para gestionar el acceso a los endpoints, el cifrado de
 * contraseñas y las políticas de CORS/CSRF.
 */
@Configuration
@EnableWebSecurity
public class ConfiguracionSeguridad {

	/**
	 * Define la cadena de filtros de seguridad (Security Filter Chain).
	 * Configuración adaptada para desarrollo ágil: protege lo sensible y abre el
	 * resto por defecto.
	 */
	@Bean
	public SecurityFilterChain cadenaFiltrosSeguridad(HttpSecurity http) throws Exception {
		http.csrf(csrf -> csrf.disable()).headers(headers -> headers.frameOptions(frame -> frame.sameOrigin()))
				.authorizeHttpRequests(solicitudes -> solicitudes

						// --- 1. RESTRICCIONES PRIVADAS (Lo que SÍ O SÍ debe estar bloqueado) ---

						// Vistas HTML privadas (Solo usuarios logueados según su rol)
						.requestMatchers("/mis-reservas.html", "/perfil.html", "/reservas.html")
						.hasAnyRole("CLIENTE", "EMPLEADO", "SUPERVISOR", "ADMIN")
						.requestMatchers("/panel-admin.html", "/gestion-clientes.html")
						.hasAnyRole("EMPLEADO", "SUPERVISOR", "ADMIN")

						// Endpoints de la API sensibles (Evita que se manipulen desde Swagger por
						// usuarios anónimos)
						.requestMatchers("/clientes/buscar-menores", "/clientes/buscar-nacionalidad-mayores")
						.hasAnyRole("EMPLEADO", "SUPERVISOR", "ADMIN")
						.requestMatchers(HttpMethod.PUT, "/reservas/*/aprobar", "/reservas/*/rechazar")
						.hasAnyRole("EMPLEADO", "SUPERVISOR", "ADMIN")
						.requestMatchers(HttpMethod.POST, "/usuarios/registro-empleado").hasRole("ADMIN")

						// --- 2. ZONA PÚBLICA ABSOLUTA (Comodines amplios para desarrollo fluido) ---

						// Herramientas de desarrollador
						.requestMatchers("/h2-console/**", "/swagger-ui/**", "/v3/api-docs/**", "/swagger-ui.html")
						.permitAll()

						// Permitimos CUALQUIER carpeta de recursos estáticos
						.requestMatchers("/css/**", "/js/**", "/img/**", "/assets/**", "/error", "/componentes/**",
								"/monitor/**", "/legalidades/**")
						.permitAll()

						// EL TRUCO DEFINITIVO: Cualquier archivo HTML que exista en el proyecto y no
						// haya sido bloqueado en el Paso 1, será público automáticamente.
						.requestMatchers("/", "/**/*.html").permitAll()

						// Vía libre a la API para hacer pruebas en Swagger sin restricciones molestas
						.requestMatchers("/clientes/**", "/paquetes/**", "/reservas/**", "/usuarios/**").permitAll()

						// --- 3. POR DEFECTO ---
						// Cualquier petición extraña que no encaje en los filtros anteriores, se
						// bloquea.
						.anyRequest().authenticated())
				.formLogin(formulario -> formulario.permitAll()).logout(salida -> salida.permitAll());

		return http.build();
	}

	/**
	 * Excepciones de seguridad a nivel web (Ignora completamente estas rutas para
	 * ganar rendimiento).
	 */
	@Bean
	public WebSecurityCustomizer webSecurityCustomizer() {
		return web -> web.ignoring().requestMatchers("/swagger-ui/**", "/swagger-ui.html", "/v3/api-docs/**",
				"/h2-console/**");
	}

	@Bean
	public PasswordEncoder codificadorContrasenas() {
		return new BCryptPasswordEncoder();
	}
}