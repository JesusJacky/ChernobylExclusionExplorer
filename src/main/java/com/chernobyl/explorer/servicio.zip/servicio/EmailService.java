package com.chernobyl.explorer.servicio;

import java.time.LocalDate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import com.chernobyl.explorer.entidades.Reserva;
import com.chernobyl.explorer.entidades.Cliente;

/**
 * Servicio encargado de la comunicación asíncrona mediante correo electrónico.
 * Gestiona el envío de plantillas de reservas, pagos y notificaciones de seguridad.
 */
@Service
public class EmailService {

	@Autowired
	private JavaMailSender emisorCorreos;

	/**
	 * Envía el comprobante inicial cuando un cliente solicita una expedición desde la web.
	 * * @param emailDestino Correo del cliente.
	 * @param clientePrincipal Datos personales del solicitante.
	 * @param reserva Datos de la expedición pendiente.
	 */
	public void enviarResguardoReserva(String emailDestino, Cliente clientePrincipal, Reserva reserva) {
		SimpleMailMessage mensaje = new SimpleMailMessage();

		mensaje.setTo(emailDestino);
		mensaje.setSubject("☢️ Expedición Pendiente de Revisión - Chernobyl Exclusion Explorer");

		String cuerpo = "Estimado/a " + clientePrincipal.getNombre() + " " + clientePrincipal.getApellido1() + ",\n\n"
				+ "Su solicitud de expedición a la Zona de Alienación ha sido registrada en nuestros sistemas y se encuentra PENDIENTE de revisión por nuestro personal autorizado.\n\n"
				+ "--- DETALLES DE LA SOLICITUD ---\n" 
				+ "📍 Localizador: " + reserva.getLocalizadorCliente() + "\n"
				+ "📅 Fecha de Emisión: " + LocalDate.now() + "\n" 
				+ "🚶 Fecha de la Expedición: " + reserva.getFechaViaje() + "\n" 
				+ "💶 Precio Total (Estimado): " + reserva.getPrecioTotal() + " €\n\n"
				+ "Recibirá una notificación en cuanto el personal haya evaluado su solicitud.\n\n"
				+ "Atentamente,\n"
				+ "El equipo de operaciones de Chernobyl Explorer.";

		mensaje.setText(cuerpo);
		emisorCorreos.send(mensaje);
	}

	/**
	 * Envía la autorización oficial cuando el personal interno aprueba la ruta.
	 * * @param emailDestino Correo del cliente.
	 * @param reserva Datos de la reserva confirmada.
	 */
	public void enviarAvisoAceptacion(String emailDestino, Reserva reserva) {
		SimpleMailMessage mensaje = new SimpleMailMessage();
		mensaje.setTo(emailDestino);
		mensaje.setSubject("✅ Expedición ACEPTADA - Chernobyl Exclusion Explorer");

		String cuerpo = "Buenas noticias,\n\n"
				+ "Tras revisar su solicitud con localizador [" + reserva.getLocalizadorCliente() + "], nuestro personal ha APROBADO su ingreso a la Zona de Exclusión para la fecha " + reserva.getFechaViaje() + ".\n\n"
				+ "--- NORMATIVA DE SEGURIDAD ---\n"
				+ "Recuerde seguir en todo momento las instrucciones de su guía asignado y no separarse del grupo. El equipo de dosimetría le será entregado en el punto de control de Dityatki.\n\n"
				+ "Atentamente,\n"
				+ "El equipo de operaciones de Chernobyl Explorer.";

		mensaje.setText(cuerpo);
		emisorCorreos.send(mensaje);
	}

	/**
	 * Envía el informe de denegación cuando el personal de seguridad cancela la expedición, 
	 * indicando motivos médicos, de aforo o climáticos.
	 * * @param emailDestino Correo del cliente.
	 * @param reserva Datos de la reserva afectada.
	 * @param motivo Explicación escrita por el supervisor en la intranet.
	 */
	public void enviarAvisoCancelacionPorPersonal(String emailDestino, Reserva reserva, String motivo) {
		SimpleMailMessage mensaje = new SimpleMailMessage();
		mensaje.setTo(emailDestino);
		mensaje.setSubject("❌ Expedición CANCELADA - Chernobyl Exclusion Explorer");

		String cuerpo = "Estimado cliente,\n\n"
				+ "Lamentamos informarle de que su solicitud de expedición con localizador [" + reserva.getLocalizadorCliente() + "] ha sido CANCELADA por nuestro equipo de seguridad y operaciones.\n\n"
				+ "Motivo de la cancelación proporcionado por el oficial a cargo:\n"
				+ ">> \"" + motivo + "\"\n\n"
				+ "--- INFORMACIÓN BANCARIA ---\n"
				+ "Si usted ya había realizado el pago o la fianza de esta reserva, le informamos de que hemos dado la orden inmediata de devolución. El abono del coste total de la reserva se verá reflejado en su mismo método de pago en un plazo prudencial de 3 a 5 días hábiles.\n\n"
				+ "Para cualquier reclamación, responda a este correo.\n\n"
				+ "Atentamente,\n"
				+ "El equipo de operaciones de Chernobyl Explorer.";

		mensaje.setText(cuerpo);
		emisorCorreos.send(mensaje);
	}

	/**
	 * Emite la factura simplificada cuando la pasarela devuelve un pago exitoso.
	 * * @param emailDestino Correo del cliente.
	 * @param reserva Datos vinculados al pago.
	 * @param transaccion Hash del recibo bancario.
	 */
	public void enviarReciboPago(String emailDestino, Reserva reserva, String transaccion) {
		SimpleMailMessage mensaje = new SimpleMailMessage();
		mensaje.setTo(emailDestino);
		mensaje.setSubject("✅ Confirmación de Pago - Chernobyl Exclusion Explorer");

		String cuerpo = "El pago de su expedición ha sido procesado con éxito.\n\n"
				+ "--- RECIBO DE LA TRANSACCIÓN ---\n" 
				+ "🆔 Transacción segura: " + transaccion + "\n"
				+ "📍 Localizador: " + reserva.getLocalizadorCliente() + "\n" 
				+ "💶 Importe abonado: " + reserva.getPrecioTotal() + " €\n\n"
				+ "Atentamente,\n"
				+ "El equipo financiero de Chernobyl Explorer.";

		mensaje.setText(cuerpo);
		emisorCorreos.send(mensaje);
	}
}