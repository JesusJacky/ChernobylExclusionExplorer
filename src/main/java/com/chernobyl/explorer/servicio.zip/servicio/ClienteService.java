package com.chernobyl.explorer.servicio;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.chernobyl.explorer.entidades.Cliente;
import com.chernobyl.explorer.excepciones.ElementoNoEncontradaException;
import com.chernobyl.explorer.excepciones.ValidacionNegocioException;
import com.chernobyl.explorer.repositorio.ClienteRepository;

/**
 * Servicio encargado de la gestión de la lógica de negocio relacionada con los clientes (expedicionarios).
 * Maneja altas, bajas, modificaciones y filtrados de seguridad basados en la edad.
 */
@Service
public class ClienteService {

	@Autowired
	private ClienteRepository clienteRepository;

	/**
	 * Recupera todos los clientes registrados en el sistema.
	 * * @return Una lista con todos los objetos {@link Cliente}.
	 */
	public List<Cliente> listarTodos() {
		return clienteRepository.findAll();
	}

	/**
	 * Busca un cliente específico utilizando su identificador único de base de datos.
	 * * @param id El identificador único del cliente.
	 * @return El objeto {@link Cliente} encontrado.
	 * @throws ElementoNoEncontradaException Si no existe ningún cliente con el ID proporcionado.
	 */
	public Cliente buscarPorId(Integer id) {
		return clienteRepository.findById(id)
				.orElseThrow(() -> new ElementoNoEncontradaException("Cliente no encontrado con el ID " + id));
	}

	/**
	 * Registra un nuevo cliente en el sistema. Aplica reglas de validación estrictas 
	 * sobre la edad mínima permitida por motivos de seguridad radiológica.
	 * * @param cliente Objeto {@link Cliente} con los datos a persistir.
	 * @return El cliente guardado con su ID generado y la fecha de alta.
	 * @throws ValidacionNegocioException Si el cliente es menor de 14 años o si tiene entre 14 y 17 años sin consentimiento.
	 */
	public Cliente crear(Cliente cliente) {
		LocalDate hoy = LocalDate.now();

		if (cliente.getFechaNacimiento() != null) {
			long edad = ChronoUnit.YEARS.between(cliente.getFechaNacimiento(), hoy);

			if (edad < 18 && !Boolean.TRUE.equals(cliente.isConsentimiento())) {
				throw new ValidacionNegocioException("Los menores de edad requieren consentimiento explícito por parte de un tutor legal.");
			}
			
			if (edad < 14) {
				throw new ValidacionNegocioException("Por motivos de seguridad radiológica, no se admiten menores de 14 años bajo ninguna circunstancia.");
			}
		}

		cliente.setFechaAlta(hoy);
		return clienteRepository.save(cliente);
	}

	/**
	 * Elimina físicamente a un cliente de la base de datos.
	 * * @param id El identificador único del cliente a eliminar.
	 * @throws ElementoNoEncontradaException Si el ID no corresponde a ningún cliente registrado.
	 */
	public void eliminar(Integer id) {
		if (!clienteRepository.existsById(id)) {
			throw new ElementoNoEncontradaException("Cliente no encontrado con el ID " + id);
		}
		clienteRepository.deleteById(id);
	}

	/**
	 * Actualiza los datos personales de un cliente existente. 
	 * El DNI se considera inmutable por motivos de trazabilidad y seguridad.
	 * * @param id El identificador del cliente a actualizar.
	 * @param detallesCliente Objeto {@link Cliente} con los nuevos datos.
	 * @return El cliente actualizado.
	 * @throws ValidacionNegocioException Si se intenta modificar el DNI.
	 */
	public Cliente actualizar(Integer id, Cliente detallesCliente) {
		Cliente clienteExistente = buscarPorId(id);

		if (!clienteExistente.getDni().equalsIgnoreCase(detallesCliente.getDni())) {
			throw new ValidacionNegocioException("Por motivos de seguridad, no está permitido modificar el DNI de un perfil existente.");
		}

		clienteExistente.setNombre(detallesCliente.getNombre());
		clienteExistente.setApellido1(detallesCliente.getApellido1());
		clienteExistente.setApellido2(detallesCliente.getApellido2());
		clienteExistente.setNacionalidad(detallesCliente.getNacionalidad());
		clienteExistente.setActivo(detallesCliente.getActivo());

		if (Boolean.FALSE.equals(detallesCliente.getActivo()) && Boolean.TRUE.equals(clienteExistente.getActivo())) {
			clienteExistente.setFechaBaja(LocalDate.now());
		}

		return clienteRepository.save(clienteExistente);
	}

	/**
	 * Filtra clientes por nacionalidad asegurándose de que sean mayores de edad (>= 18 años).
	 * Utilizado para expediciones internacionales que requieren mayoría de edad.
	 * * @param nacionalidad La nacionalidad a filtrar (ignorando mayúsculas y minúsculas).
	 * @return Lista de clientes que cumplen ambas condiciones.
	 * @throws ElementoNoEncontradaException Si no se encuentra ninguna coincidencia.
	 */
	public List<Cliente> buscarPorNacionalidadYMayorDeEdad(String nacionalidad) {
		List<Cliente> todosClientes = clienteRepository.findAll();
		LocalDate hoy = LocalDate.now();
		int mayoriaEdad = 18;

		List<Cliente> resultado = todosClientes.stream()
				.filter(c -> nacionalidad.equalsIgnoreCase(c.getNacionalidad()))
				.filter(c -> c.getFechaNacimiento() != null && ChronoUnit.YEARS.between(c.getFechaNacimiento(), hoy) >= mayoriaEdad)
				.toList();

		if (resultado.isEmpty()) {
			throw new ElementoNoEncontradaException("No se ha encontrado un cliente con la nacionalidad " + nacionalidad + " y que sea mayor de edad");
		}
		return resultado;
	}

	/**
	 * Obtiene un listado de todos los clientes activos que sean menores de 18 años.
	 * Utilizado por el personal para gestionar protocolos de seguridad adicionales.
	 * * @return Lista de clientes menores de edad activos.
	 * @throws ElementoNoEncontradaException Si no existen menores registrados y activos.
	 */
	public List<Cliente> filtrarPorMenorDeEdad() {
		List<Cliente> todosClientes = clienteRepository.findAll();
		LocalDate hoy = LocalDate.now();
		int mayoriaEdad = 18;

		List<Cliente> resultado = todosClientes.stream()
				.filter(c -> c.getFechaNacimiento() != null && ChronoUnit.YEARS.between(c.getFechaNacimiento(), hoy) < mayoriaEdad)
				.filter(c -> Boolean.TRUE.equals(c.getActivo())).toList();

		if (resultado.isEmpty()) {
			throw new ElementoNoEncontradaException("No se ha encontrado ningún menor de edad activo.");
		}
		return resultado;
	}

	/**
	 * Busca un perfil de cliente exacto utilizando su Documento Nacional de Identidad.
	 * * @param dni El DNI a buscar.
	 * @return El objeto {@link Cliente} que coincide con el DNI.
	 * @throws ElementoNoEncontradaException Si no existe ningún cliente con ese DNI.
	 */
	public Cliente buscarPorDni(String dni) {
		List<Cliente> todosClientes = clienteRepository.findAll();

		return todosClientes.stream().filter(c -> c.getDni().equalsIgnoreCase(dni))
				.findFirst()
				.orElseThrow(() -> new ElementoNoEncontradaException("No se ha encontrado ningún cliente con el DNI " + dni));
	}
}